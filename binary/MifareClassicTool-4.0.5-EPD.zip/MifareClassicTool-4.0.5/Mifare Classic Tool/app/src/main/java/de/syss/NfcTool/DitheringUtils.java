package de.syss.NfcTool;


import android.graphics.Bitmap;
import android.graphics.Color;

public class DitheringUtils {
    public static int[][] dither2col(Bitmap image)
    {
        Color[] palette = new Color[] {
            Color.valueOf(0, 0, 0),
            Color.valueOf(1, 0, 0),
            Color.valueOf(1, 1, 1)
        };

        int width = image.getWidth();
        int height = image.getHeight();

        Color[][] buffer = new Color[height][width];
        int ret[][] = new int[height][width];

        for(int y=0;y<height;y++) {
            for(int x=0;x<width;x++) {
                buffer[y][x] = Color.valueOf(image.getPixel(x, y));
            }
        }

        for(int y=0; y<image.getHeight();y++) {
            for(int x=0; x<image.getWidth();x++) {
                Color old = buffer[y][x];
                int idx;
                ret[y][x] = idx = findClosestPaletteColorIdx(old, palette);
                Color error = sub(old, palette[idx]);

                if (x+1 < width)         buffer[y  ][x+1] = add(buffer[y  ][x+1], mul(error, 7./16));
                if (x-1>=0 && y+1<height) buffer[y+1][x-1] = add(buffer[y+1][x-1], mul(error, 3./16));
                if (y+1 < height)         buffer[y+1][x  ] = add(buffer[y+1][x  ], mul(error, 5./16));
                if (x+1<width && y+1<height)  buffer[y+1][x+1] = add(buffer[y+1][x+1], mul(error, 1./16));
            }
        }

        return ret;
    }
    public static Bitmap dithering(Bitmap image) {
        Color[] palette = new Color[] {
            Color.valueOf(0, 0, 0),
            Color.valueOf(1, 0, 0),
            Color.valueOf(1, 1, 1)
        };

        Bitmap ret = image.copy(Bitmap.Config.ARGB_8888, true);

        int width = image.getWidth();
        int height = image.getHeight();

        Color[][] buffer = new Color[height][width];

        for(int y=0;y<height;y++) {
            for(int x=0;x<width;x++) {
                buffer[y][x] = Color.valueOf(image.getPixel(x, y));
            }
        }

        for(int y=0; y<image.getHeight();y++) {
            for(int x=0; x<image.getWidth();x++) {
                Color old = buffer[y][x];
                Color nem = findClosestPaletteColor(old, palette);
                ret.setPixel(x, y, nem.toArgb());
                // ret.setPixel(x, y, old.toArgb());


                Color error = sub(old, nem);

                if (x+1 < width)         buffer[y  ][x+1] = add(buffer[y  ][x+1], mul(error, 7./16));
                if (x-1>=0 && y+1<height) buffer[y+1][x-1] = add(buffer[y+1][x-1], mul(error, 3./16));
                if (y+1 < height)         buffer[y+1][x  ] = add(buffer[y+1][x  ], mul(error, 5./16));
                if (x+1<width && y+1<height)  buffer[y+1][x+1] = add(buffer[y+1][x+1], mul(error, 1./16));
            }
        }

        return ret;
    }

    public static Color add(Color a, Color b) {
        return Color.valueOf(a.red() + b.red(), a.green() + b.green(), a.blue() + b.blue());
    }
    public static Color sub(Color a, Color b) {
        return Color.valueOf(a.red() - b.red(), a.green() - b.green(), a.blue() - b.blue());
    }
    public static Color mul(Color a, double d) {
        return Color.valueOf((float) (a.red() * d), (float) (a.green() * d), (float) (a.blue() * d));
    }

    public static float diff(Color a, Color b) {
        float Rdiff = b.red() - a.red();
        float Gdiff = b.green() - a.green();
        float Bdiff = b.blue() - a.blue();
        float distanceSquared = Rdiff * Rdiff + Gdiff * Gdiff + Bdiff * Bdiff;
        return distanceSquared;
    }
    private static Color findClosestPaletteColor(Color match, Color[] palette) {
        Color closest = palette[0];

        for(Color color : palette) {
            if(diff(color, match) < diff(closest, match)) {
                closest = color;
            }
        }

        return closest;
    }
    private static int findClosestPaletteColorIdx(Color match, Color[] palette) {
        int closest = 0;

        // for(Color color : palette) {
        for (int i = 0; i < palette.length; ++i) {
            if(diff(palette[i], match) < diff(palette[closest], match)) {
                closest = i;
            }
        }

        return closest + 1;
    }
}

//class Color3i {
//
//    private int r, g, b;
//
////    public Color3i(int c) {
////        Color color = new Color(c);
////        this.r = color.getRed();
////        this.g = color.getGreen();
////        this.b = color.getBlue();
////    }
//
//    public Color3i(Color c) {
//        this.r = (int) c.red();
//        this.g = (int) c.green();
//        this.b = (int) c.blue();
//    }
//    public Color3i(int r, int g, int b) {
//        this.r = r;
//        this.g = g;
//        this.b = b;
//    }
//
//    public Color3i add(Color3i o) {
//        return new Color3i(r + o.r, g + o.g, b + o.b);
//    }
//
//    public Color3i sub(Color3i o) {
//        return new Color3i(r - o.r, g - o.g, b - o.b);
//    }
//
//    public Color3i mul(double d) {
//        return new Color3i((int) (d * r), (int) (d * g), (int) (d * b));
//    }
//
//    public int diff(Color3i o) {
//        int Rdiff = o.r - r;
//        int Gdiff = o.g - g;
//        int Bdiff = o.b - b;
//        int distanceSquared = Rdiff * Rdiff + Gdiff * Gdiff + Bdiff * Bdiff;
//        return distanceSquared;
//    }
//
//    public int toRGB() {
//        return toColor().toArgb();
//    }
//
//    public Color toColor() {
//        return Color.valueOf(clamp(r), clamp(g), clamp(b));
//    }
//
//    public int clamp(int c) {
//        return Math.max(0, Math.min(255, c));
//    }
//}
