/**
 * All Android Activities.
 */
package de.syss.NfcTool.Activities;
